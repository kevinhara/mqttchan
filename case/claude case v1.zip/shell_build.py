"""
Parametric shell for the avatar-demo enclosure.
Assembly coordinate system = tinker.obj coordinates, millimetres.
  +X = rearward (0 = front face, screens look toward -X)
  +Y = across the unit (0 = the taller module's outer edge)
  +Z = up (0 = underside of the base tray)
"""
import numpy as np, trimesh
from trimesh.creation import box, cylinder
from trimesh.boolean import union, difference

E = 'manifold'

# ----------------------------------------------------------------- CONFIG
WALL      = 2.4     # general wall thickness
DECK      = 2.4     # top surface of the base tray
TRAY_X    = 49.9    # tray depth
TRAY_Y    = 57.6    # tray width

HEAD_FRONT_D = 6.9  # depth of the existing front slab
HEAD_BACK_X  = 37.4 # rear face of the existing head geometry

MODA_Y  = (0.6, 29.0)   # taller module, user's right
MODB_Y  = (29.0, 57.0)  # shorter module, user's left
MODA_TOP, MODA_CEIL = 42.0, 40.2
MODB_TOP, MODB_CEIL = 32.0, 31.2

BAY_TOP = 11.0      # underside of the taller module's front slab

# tray mounting posts (Ø2.4, tops at z=10.9) - keep-out
POSTS = [(21.35, 5.9), (21.35, 52.8), (44.7, 5.9), (44.7, 52.8)]

# ESP32 devkit footprint on the tray, derived from the post pattern
BOARD_X = (20.2, 45.7)
BOARD_Y = (3.4, 54.9)
USB_X   = (27.5, 38.5)   # side cutout, matches the tray notch at x 29.8-36.2
USB_Z   = (DECK, 9.5)

# components
PIEZO_D, PIEZO_H = 10.0, 5.0
PIEZO_C   = (11.0, 8.9)  # (y, z) of the buzzer axis
LED_D     = 5.0
LED_C     = (24.0, 6.7)  # (y, z)
BTN_BODY, BTN_H, BTN_PLUNGE = 6.0, 3.5, 1.5
BTN_C     = (22.0, 15.0) # (x, y) on the top plate
BTN_AP    = (16.0, 11.0) # aperture x by y
CLR       = 0.3          # sliding clearance

SCREWS = [(10.0, 6.0), (10.0, 51.0), (47.0, 20.0), (47.0, 38.0)]
SCREW_PILOT, SCREW_OD = 2.5, 5.6   # M3 self-tapping

# ----------------------------------------------------------------- helpers
def blk(x0, y0, z0, x1, y1, z1):
    x0, x1 = sorted((x0, x1)); y0, y1 = sorted((y0, y1)); z0, z1 = sorted((z0, z1))
    m = box(extents=(x1-x0, y1-y0, z1-z0))
    m.apply_translation(((x0+x1)/2, (y0+y1)/2, (z0+z1)/2))
    return m

def tube(axis, a, b, c1, c2, d, sections=64):
    """cylinder of diameter d running along `axis` from a to b, centred at (c1,c2)"""
    a, b = sorted((a, b))
    m = cylinder(radius=d/2, height=b-a, sections=sections)
    if axis == 'x':
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi/2, [0,1,0]))
        m.apply_translation(((a+b)/2, c1, c2))
    elif axis == 'y':
        m.apply_transform(trimesh.transformations.rotation_matrix(-np.pi/2, [1,0,0]))
        m.apply_translation((c1, (a+b)/2, c2))
    else:
        m.apply_translation((c1, c2, (a+b)/2))
    return m

# ----------------------------------------------------------------- shell
solid, cut = [], []

BACK_X = TRAY_X            # shell now runs back flush with the tray
YA0, YA1 = MODA_Y
YB0, YB1 = MODB_Y

# side walls
solid.append(blk(HEAD_FRONT_D, YA0, DECK, BACK_X, YA0+WALL, MODA_TOP))
solid.append(blk(HEAD_FRONT_D, YB1-WALL, DECK, BACK_X, YB1, MODB_TOP))
# back wall, in two heights
solid.append(blk(BACK_X-WALL, YA0, DECK, BACK_X, YA1, MODA_TOP))
solid.append(blk(BACK_X-WALL, YA1, DECK, BACK_X, YB1, MODB_TOP))
# roof over the newly added rear section
solid.append(blk(HEAD_BACK_X-WALL, YA0, MODA_CEIL, BACK_X, YA1, MODA_TOP))
solid.append(blk(HEAD_BACK_X-WALL, YA1, MODB_CEIL, BACK_X, YB1, MODB_TOP))
# the step face between the two module heights
solid.append(blk(HEAD_FRONT_D, YA1-WALL, MODB_TOP, BACK_X, YA1, MODA_TOP))

# bay face plate, closing the letterbox under the taller module
solid.append(blk(0.0, YA0, DECK, 2.0, YA1, BAY_TOP))
solid.append(blk(0.0, YA0, DECK, HEAD_FRONT_D, YA0+WALL, BAY_TOP))

# speaker grille: three slots
for zc in (4.6, 6.8, 9.0):
    cut.append(blk(-1, 3.0, zc-0.7, 3.0, 19.0, zc+0.7))
# LED port
cut.append(tube('x', -1, 3.0, LED_C[0], LED_C[1], LED_D+0.2))
solid.append(tube('x', 2.0, 8.0, LED_C[0], LED_C[1], LED_D+3.0))
cut.append(tube('x', 1.5, 9.0, LED_C[0], LED_C[1], LED_D+0.2))

# piezo cradle
solid.append(tube('x', HEAD_FRONT_D, HEAD_FRONT_D+PIEZO_H-1.0, PIEZO_C[0], PIEZO_C[1], PIEZO_D+3.0))
cut.append(tube('x', HEAD_FRONT_D-1, HEAD_FRONT_D+PIEZO_H+1, PIEZO_C[0], PIEZO_C[1], PIEZO_D+0.3))

# USB cutout in the +Y wall
cut.append(blk(USB_X[0], YB1-WALL-1, USB_Z[0], USB_X[1], YB1+1, USB_Z[1]))

# screw bosses
for (sx, sy) in SCREWS:
    solid.append(tube('z', DECK, 12.0, sx, sy, SCREW_OD))
    cut.append(tube('z', DECK-1, 12.5, sx, sy, SCREW_PILOT))

# ----------------------------------------------------------------- button
bx, by = BTN_C
SW_TIP   = 38.3                      # plunger tip at rest
SW_FLOOR = SW_TIP - BTN_PLUNGE - BTN_H
solid.append(blk(bx-4.6, by-4.6, SW_FLOOR, bx+4.6, by+4.6, MODA_CEIL))
cut.append(blk(bx-(BTN_BODY+CLR)/2, by-(BTN_BODY+CLR)/2, SW_FLOOR+1.6,
               bx+(BTN_BODY+CLR)/2, by+(BTN_BODY+CLR)/2, MODA_CEIL+1))
cut.append(blk(bx-2.0, by-5.6, SW_FLOOR, bx+2.0, by-3.0, SW_FLOOR+3.0))  # wire exit
for sgn in (-1, 1):                                                       # print gussets
    g = blk(bx-4.6, by+sgn*4.6-0.0, SW_FLOOR, bx+4.6, by+sgn*4.6+sgn*3.0, SW_FLOOR+3.0)
    solid.append(g)

# aperture through the existing top plate -> delivered as a separate cutter
aperture = blk(bx-BTN_AP[0]/2, by-BTN_AP[1]/2, MODA_CEIL-1,
               bx+BTN_AP[0]/2, by+BTN_AP[1]/2, MODA_TOP+1)

# the cap itself, a separate print, loads from underneath
cap = union([
    blk(bx-(BTN_AP[0]-2*CLR)/2, by-(BTN_AP[1]-2*CLR)/2, MODA_CEIL, 
        bx+(BTN_AP[0]-2*CLR)/2, by+(BTN_AP[1]-2*CLR)/2, MODA_TOP+1.2),
    blk(bx-9.5, by-7.0, MODA_CEIL-1.5, bx+9.5, by+7.0, MODA_CEIL),
    tube('z', SW_TIP+0.1, MODA_CEIL-1.5, bx, by, 3.5),
], engine=E)

# ----------------------------------------------------------------- assemble
shell = union(solid, engine=E)
shell = difference([shell] + cut, engine=E)

for name, mesh in [('shell_addon', shell), ('button_cap', cap), ('button_aperture_cutter', aperture)]:
    mesh.export(f'/home/claude/gen/{name}.stl')
    print(f'{name:24s} watertight={mesh.is_watertight!s:5s} vol={mesh.volume/1000:7.2f} cm3 '
          f'bbox={np.round(mesh.bounds[1]-mesh.bounds[0],1)}')

# ------------------------------------------------ tray drilling (apply to zqn_case_lid)
tray_cut = []
for (sx, sy) in SCREWS:
    tray_cut.append(tube('z', -1, DECK+1, sx, sy, 3.2))      # M3 clearance
    tray_cut.append(tube('z', -1, 1.4,   sx, sy, 6.4))       # counterbore for the head
tc = union(tray_cut, engine=E)
tc.export('/home/claude/gen/tray_screw_cutter.stl')
print(f'{"tray_screw_cutter":24s} watertight={tc.is_watertight!s:5s} bbox={np.round(tc.bounds[1]-tc.bounds[0],1)}')
